from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlparse
import sys

ROOT = Path(__file__).resolve().parents[1]
INDEX = ROOT / "index.html"

class Parser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids=set()
        self.refs=[]
        self.forms=[]
        self.canonical=None
    def handle_starttag(self, tag, attrs):
        d=dict(attrs)
        if "id" in d: self.ids.add(d["id"])
        if tag in {"img","script","link","a"}:
            key={"img":"src","script":"src","link":"href","a":"href"}[tag]
            if d.get(key): self.refs.append((tag,d[key]))
        if tag=="form":
            self.forms.append((d.get("action",""),d.get("method","").upper()))
        if tag=="link" and d.get("rel")=="canonical":
            self.canonical=d.get("href")

html=INDEX.read_text(encoding="utf-8")
p=Parser(); p.feed(html)
errors=[]

if (ROOT/"CNAME").read_text().strip()!="2026itstime.com":
    errors.append("CNAME must contain exactly 2026itstime.com")
if p.canonical!="https://2026itstime.com/":
    errors.append("Canonical URL must be https://2026itstime.com/")
if "Morriseau" in html:
    errors.append("Legacy surname Morriseau appears in public index.html")
if len(p.forms)!=2:
    errors.append(f"Expected 2 forms, found {len(p.forms)}")
for action,method in p.forms:
    if action!="https://formsubmit.co/2026itstime@gmail.com" or method!="POST":
        errors.append(f"Unexpected form endpoint/method: {method} {action}")

for tag,ref in p.refs:
    if ref.startswith("#") and len(ref)>1:
        if ref[1:] not in p.ids:
            errors.append(f"Broken internal anchor: {ref}")
        continue
    if ref.startswith(("http://","https://","mailto:","tel:","data:","javascript:","#")):
        continue
    path=ref.split("#",1)[0].split("?",1)[0].lstrip("/")
    if path and not (ROOT/path).exists():
        errors.append(f"Missing local asset referenced by {tag}: {ref}")

for required in [
    "index.html","404.html","CNAME",".nojekyll","robots.txt","sitemap.xml",
    "site.webmanifest","assets/css/site.css","assets/js/site.js",
    "assets/images/cynthia-hero.jpg","assets/images/campaign-mark.png",
]:
    if not (ROOT/required).exists():
        errors.append(f"Missing required file: {required}")

if errors:
    print("\n".join(f"ERROR: {e}" for e in errors))
    sys.exit(1)

print("Static site validation passed.")
